package com.codmstretch.hook;

import android.graphics.Rect;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Runs inside system_server (scope: System Framework).
 *
 * When the display size is overridden to a different aspect ratio ("wm size"), Android
 * keeps the picture's shape and centers it with black bars. This hook replaces that
 * centered "display rect" with the full panel, so SurfaceFlinger stretches the picture
 * to fill the screen. Touch input follows because the input viewport is built from the
 * same rect.
 *
 * It does nothing when there are no bars, when /data/system/codm_stretch_off exists,
 * or for non-built-in displays. Status is written to /data/system/codm_stretch_hook.txt.
 */
public class StretchHook implements IXposedHookLoadPackage {
    private static final String STATUS_FILE = "/data/system/codm_stretch_hook.txt";
    private static final String OFF_FILE = "/data/system/codm_stretch_off";
    private static final String TARGET = "com.android.server.display.DisplayDevice";

    private static volatile boolean hooked = false;
    private static volatile String message = "starting";
    private static volatile String last = "";
    private static volatile int events = 0;
    private static volatile long lastWrite = 0;
    private static volatile String bootId = "";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (lp == null || !"android".equals(lp.packageName)) return;
        try {
            bootId = firstLine("/proc/sys/kernel/random/boot_id");
            Class<?> cls = XposedHelpers.findClassIfExists(TARGET, lp.classLoader);
            if (cls == null) {
                message = "DisplayDevice class not found";
            } else {
                Set<?> set = XposedBridge.hookAllMethods(cls, "setProjectionLocked", new ProjectionHook());
                hooked = set != null && !set.isEmpty();
                message = hooked ? "hooked setProjectionLocked x" + set.size()
                                 : "setProjectionLocked not found";
            }
        } catch (Throwable t) {
            message = "load error " + t.getClass().getSimpleName();
            XposedBridge.log(t);
        }
        writeStatus(true);
    }

    private static final class ProjectionHook extends XC_MethodHook {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                if (new File(OFF_FILE).exists()) return;
                Object[] a = param.args;
                int first = -1;
                int second = -1;
                for (int i = 0; i < a.length; i++) {
                    if (a[i] instanceof Rect) {
                        if (first < 0) {
                            first = i;
                        } else if (second < 0) {
                            second = i;
                        }
                    }
                }
                // args: (transaction, orientation, layerStackRect, displayRect)
                if (second < 0) return;
                if (!isInternal(param.thisObject)) return;

                Rect disp = (Rect) a[second];
                int left = disp.left;
                int top = disp.top;
                if (left <= 0 && top <= 0) return; // already fills the panel

                // The bars are centered, so the full panel is the rect plus the offsets.
                Rect full = new Rect(0, 0, disp.right + left, disp.bottom + top);
                a[second] = full;

                events++;
                last = "from " + disp.toShortString() + " to " + full.toShortString();
                writeStatus(false);
            } catch (Throwable t) {
                message = "hook error " + t.getClass().getSimpleName();
                writeStatus(false);
            }
        }
    }

    private static boolean isInternal(Object device) {
        try {
            Object info = XposedHelpers.callMethod(device, "getDisplayDeviceInfoLocked");
            return XposedHelpers.getIntField(info, "type") == 1; // Display.TYPE_INTERNAL
        } catch (Throwable t) {
            return true;
        }
    }

    private static void writeStatus(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastWrite < 2000) return;
        lastWrite = now;
        try {
            String s = "hooked=" + (hooked ? 1 : 0) + "\n"
                    + "boot_id=" + bootId + "\n"
                    + "epoch=" + (now / 1000) + "\n"
                    + "msg=" + message + "\n"
                    + "events=" + events + "\n"
                    + "last=" + last + "\n";
            FileOutputStream out = new FileOutputStream(STATUS_FILE, false);
            try {
                out.write(s.getBytes("UTF-8"));
            } finally {
                out.close();
            }
        } catch (Throwable ignored) {
            // status is best-effort only
        }
    }

    private static String firstLine(String path) {
        try {
            BufferedReader r = new BufferedReader(new FileReader(path));
            try {
                String l = r.readLine();
                return l == null ? "" : l.trim();
            } finally {
                r.close();
            }
        } catch (Throwable t) {
            return "";
        }
    }
}
