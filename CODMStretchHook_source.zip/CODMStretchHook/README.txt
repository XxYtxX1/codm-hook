CODM Stretch Hook (LSPosed module)
==================================
Makes the screen fill the whole panel (stretch) instead of black bars when the
display size uses a different aspect ratio. Pair with the CODM Ultra Stretch module.

Build: push this folder to a GitHub repo -> Actions tab -> "Build CODM Stretch Hook"
-> download CODM-Stretch-Hook.apk from the run's Artifacts or from Releases.
(Or: gradle :app:assembleDebug with Android SDK 34 + JDK 17.)

Use: install the APK -> LSPosed -> Modules -> enable "CODM Stretch Hook" with the
System Framework scope -> reboot. The module's WebUI shows 'Fill hook: Loaded'.
Hook status file: /data/system/codm_stretch_hook.txt
Kill switch: create /data/system/codm_stretch_off (the module's Fill toggle does this).
